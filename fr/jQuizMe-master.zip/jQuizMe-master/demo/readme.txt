Programmer: Larry Battle
Date: July 20, 2011

The demos in the HowToDemos use the following.
jQuery 1.4.4
jQuizMe 2.1.9 Beta