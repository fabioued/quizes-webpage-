## Note:
Project is retired and not under active development.


## jQuizMe

jQuizMe is a webpage quiz application made with jQuery. Uses javascript and css. You can make the following types of quizzes.

- Fill In The Blank
- Flash Cards
- Multiple Choice (list or options tags)
- True or False

##Note: 
- Original home at https://code.google.com/p/jquizme/
- Checkout the release branches.
- Version 3 is in development, maybe...
